import csv
from pathlib import Path
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox

# Store data beside this Python file, not in whichever folder VS Code uses.
PROJECT_DIR = Path(__file__).resolve().parent
EXPENSE_FILE = PROJECT_DIR / "expenses.csv"
ALLOWANCE_FILE = PROJECT_DIR / "allowance.csv"

CATEGORIES = ["Food", "Travel", "Shopping", "Bills", "Others"]


def initialize_files():
    """Create the CSV files with headers when they do not already exist."""
    if not EXPENSE_FILE.exists():
        with EXPENSE_FILE.open("w", newline="", encoding="utf-8") as file:
            csv.writer(file).writerow(["Date", "Category", "Amount", "Note"])

    if not ALLOWANCE_FILE.exists():
        with ALLOWANCE_FILE.open("w", newline="", encoding="utf-8") as file:
            csv.writer(file).writerow(["MonthYear", "Allowance"])


def read_allowance(month_year):
    """Return the allowance for MM/YYYY, or None if it has not been set."""
    with ALLOWANCE_FILE.open("r", newline="", encoding="utf-8") as file:
        for row in csv.DictReader(file):
            if row.get("MonthYear") == month_year:
                try:
                    return int(row["Allowance"])
                except (ValueError, TypeError):
                    return None
    return None


def save_allowance(month_year, amount):
    """Add or update the allowance for a month."""
    rows = []
    found = False

    with ALLOWANCE_FILE.open("r", newline="", encoding="utf-8") as file:
        reader = csv.DictReader(file)
        for row in reader:
            if row.get("MonthYear") == month_year:
                row["Allowance"] = str(amount)
                found = True
            rows.append(row)

    if not found:
        rows.append({"MonthYear": month_year, "Allowance": str(amount)})

    with ALLOWANCE_FILE.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=["MonthYear", "Allowance"])
        writer.writeheader()
        writer.writerows(rows)


def read_expenses():
    """Read all valid expense rows from the CSV file."""
    expenses = []
    with EXPENSE_FILE.open("r", newline="", encoding="utf-8") as file:
        for row in csv.DictReader(file):
            try:
                datetime.strptime(row["Date"], "%d/%m/%Y")
                amount = int(row["Amount"])
                if amount >= 0:
                    expenses.append({
                        "date": row["Date"],
                        "category": row["Category"],
                        "amount": amount,
                        "note": row.get("Note", "")
                    })
            except (KeyError, ValueError, TypeError):
                # Ignore malformed rows rather than crashing the application.
                continue
    return expenses


def add_expense(date_text, category, custom_category, amount_text, note):
    """Validate and save one expense. Returns an error message or None."""
    try:
        expense_date = datetime.strptime(date_text.strip(), "%d/%m/%Y")
    except ValueError:
        return "Enter a valid date in DD/MM/YYYY format."

    selected_category = category
    if selected_category == "Others":
        selected_category = custom_category.strip() or "Others"

    try:
        amount = int(amount_text.strip())
        if amount <= 0:
            return "Amount must be greater than zero."
    except ValueError:
        return "Amount must be a whole number (for example, 250)."

    month_year = expense_date.strftime("%m/%Y")

    # Ask for an allowance the first time an expense is added for a month.
    if read_allowance(month_year) is None:
        allowance = ask_allowance(month_year)
        if allowance is not None:
            save_allowance(month_year, allowance)

    with EXPENSE_FILE.open("a", newline="", encoding="utf-8") as file:
        csv.writer(file).writerow([
            expense_date.strftime("%d/%m/%Y"),
            selected_category,
            amount,
            note.strip()
        ])

    return None


def ask_allowance(month_year):
    """Ask for the month's allowance; None means the user cancelled."""
    dialog = tk.Toplevel(root)
    dialog.title("Set Monthly Allowance")
    dialog.resizable(False, False)
    dialog.transient(root)
    dialog.grab_set()

    ttk.Label(
        dialog,
        text=f"Enter your monthly allowance for {month_year} (Rs.):"
    ).pack(padx=18, pady=(18, 8))

    value = tk.StringVar()
    entry = ttk.Entry(dialog, textvariable=value, width=22)
    entry.pack(padx=18, pady=5)
    entry.focus_set()

    result = {"amount": None}

    def submit():
        try:
            amount = int(value.get().strip())
            if amount < 0:
                raise ValueError
        except ValueError:
            messagebox.showerror(
                "Invalid allowance",
                "Enter a non-negative whole number.",
                parent=dialog
            )
            return
        result["amount"] = amount
        dialog.destroy()

    def cancel():
        dialog.destroy()

    buttons = ttk.Frame(dialog)
    buttons.pack(pady=(10, 16))
    ttk.Button(buttons, text="Save", command=submit).pack(side="left", padx=5)
    ttk.Button(buttons, text="Cancel", command=cancel).pack(side="left", padx=5)
    dialog.bind("<Return>", lambda event: submit())
    dialog.bind("<Escape>", lambda event: cancel())

    root.wait_window(dialog)
    return result["amount"]


def show_text(content):
    output.configure(state="normal")
    output.delete("1.0", tk.END)
    output.insert(tk.END, content)
    output.configure(state="disabled")


def clear_entries():
    date_entry.delete(0, tk.END)
    amount_entry.delete(0, tk.END)
    note_entry.delete(0, tk.END)
    custom_entry.delete(0, tk.END)
    category_combo.set(CATEGORIES[0])
    date_entry.focus_set()


def on_add_expense():
    error = add_expense(
        date_entry.get(),
        category_combo.get(),
        custom_entry.get(),
        amount_entry.get(),
        note_entry.get()
    )
    if error:
        messagebox.showerror("Cannot add expense", error, parent=root)
        return

    messagebox.showinfo("Success", "Expense added successfully.", parent=root)
    clear_entries()
    show_text("Expense saved successfully. Use the Daily or Monthly report to view your spending.")


def on_view_day():
    date_text = date_entry.get().strip()
    try:
        parsed_date = datetime.strptime(date_text, "%d/%m/%Y")
        date_text = parsed_date.strftime("%d/%m/%Y")
    except ValueError:
        messagebox.showerror("Invalid date", "Enter a valid date in DD/MM/YYYY format.", parent=root)
        return

    matches = [item for item in read_expenses() if item["date"] == date_text]
    if not matches:
        show_text(f"No expenses found for {date_text}.")
        return

    total = sum(item["amount"] for item in matches)
    category_totals = {}
    lines = [f"DAILY EXPENSE REPORT — {date_text}", "=" * 40]
    for item in matches:
        lines.append(
            f'{item["category"]}: Rs. {item["amount"]} — {item["note"]}'
        )
        category_totals[item["category"]] = (
            category_totals.get(item["category"], 0) + item["amount"]
        )

    lines.extend(["", f"Total spent: Rs. {total}", "", "Advice:"])
    advice = [
        f"- {category} accounts for {amount / total:.0%} of today's spending. Consider reducing it."
        for category, amount in category_totals.items()
        if total > 0 and amount / total >= 0.5
    ]
    lines.extend(advice or ["Good balance today!"])
    show_text("\n".join(lines))


def on_view_month():
    month_text = month_entry.get().strip()
    try:
        parsed_month = datetime.strptime(month_text, "%m/%Y")
        month_text = parsed_month.strftime("%m/%Y")
    except ValueError:
        messagebox.showerror("Invalid month", "Enter month and year in MM/YYYY format.", parent=root)
        return

    matches = [
        item for item in read_expenses()
        if datetime.strptime(item["date"], "%d/%m/%Y").strftime("%m/%Y") == month_text
    ]
    if not matches:
        show_text(f"No expenses found for {month_text}.")
        return

    total = sum(item["amount"] for item in matches)
    category_totals = {}
    for item in matches:
        category_totals[item["category"]] = (
            category_totals.get(item["category"], 0) + item["amount"]
        )

    allowance = read_allowance(month_text)
    lines = [f"MONTHLY SUMMARY — {month_text}", "=" * 40]
    lines.append(f"Allowance: Rs. {allowance}" if allowance is not None else "Allowance: Not set")
    lines.append(f"Total spent: Rs. {total}")
    if allowance is not None:
        remaining = allowance - total
        lines.append(f"Remaining: Rs. {remaining}")
        if remaining < 0:
            lines.append(f"Over allowance by: Rs. {abs(remaining)}")

    lines.extend(["", "CATEGORY-WISE BREAKDOWN:"])
    for category, amount in category_totals.items():
        lines.append(f"- {category}: Rs. {amount}")

    lines.extend(["", "Advice:"])
    if allowance is None:
        lines.append("Set an allowance to receive allowance-based spending advice.")
    elif allowance == 0:
        lines.append("Your allowance is Rs. 0, so percentage-based advice is not available.")
    else:
        advice = [
            f"- {category} accounts for {amount / allowance:.0%} of your allowance. Consider reducing it."
            for category, amount in category_totals.items()
            if amount / allowance >= 0.2
        ]
        lines.extend(advice or ["Great job! You managed your expenses well this month."])

    show_text("\n".join(lines))


# Create the data files before the GUI starts.
initialize_files()

root = tk.Tk()
root.title("Personal Expense Tracker")
root.geometry("850x650")
root.minsize(720, 560)

style = ttk.Style()
if "clam" in style.theme_names():
    style.theme_use("clam")

main_frame = ttk.Frame(root, padding=16)
main_frame.pack(fill="both", expand=True)

ttk.Label(
    main_frame,
    text="Personal Expense Tracker",
    font=("Segoe UI", 20, "bold")
).pack(anchor="w")

ttk.Label(
    main_frame,
    text="Record expenses and review your daily and monthly spending.",
    font=("Segoe UI", 10)
).pack(anchor="w", pady=(2, 14))

entry_frame = ttk.LabelFrame(main_frame, text="Add an Expense", padding=12)
entry_frame.pack(fill="x")

ttk.Label(entry_frame, text="Date (DD/MM/YYYY)").grid(row=0, column=0, sticky="w", padx=5, pady=5)
date_entry = ttk.Entry(entry_frame, width=20)
date_entry.grid(row=0, column=1, sticky="w", padx=5, pady=5)
date_entry.insert(0, datetime.today().strftime("%d/%m/%Y"))

ttk.Label(entry_frame, text="Category").grid(row=0, column=2, sticky="w", padx=5, pady=5)
category_combo = ttk.Combobox(entry_frame, values=CATEGORIES, state="readonly", width=18)
category_combo.grid(row=0, column=3, sticky="w", padx=5, pady=5)
category_combo.set("Food")

ttk.Label(entry_frame, text="Custom category (if Others)").grid(row=1, column=0, sticky="w", padx=5, pady=5)
custom_entry = ttk.Entry(entry_frame, width=20)
custom_entry.grid(row=1, column=1, sticky="w", padx=5, pady=5)

ttk.Label(entry_frame, text="Amount (Rs.)").grid(row=1, column=2, sticky="w", padx=5, pady=5)
amount_entry = ttk.Entry(entry_frame, width=21)
amount_entry.grid(row=1, column=3, sticky="w", padx=5, pady=5)

ttk.Label(entry_frame, text="Note / Description").grid(row=2, column=0, sticky="w", padx=5, pady=5)
note_entry = ttk.Entry(entry_frame)
note_entry.grid(row=2, column=1, columnspan=3, sticky="ew", padx=5, pady=5)
entry_frame.columnconfigure(3, weight=1)

ttk.Button(entry_frame, text="Add Expense", command=on_add_expense).grid(
    row=3, column=0, columnspan=4, pady=(12, 3)
)

report_frame = ttk.LabelFrame(main_frame, text="View Reports", padding=12)
report_frame.pack(fill="x", pady=12)

ttk.Label(report_frame, text="Daily date (use date above)").grid(row=0, column=0, sticky="w", padx=5, pady=5)
ttk.Button(report_frame, text="View Daily Expenses", command=on_view_day).grid(row=0, column=1, padx=5, pady=5)

ttk.Label(report_frame, text="Month / Year (MM/YYYY)").grid(row=1, column=0, sticky="w", padx=5, pady=5)
month_entry = ttk.Entry(report_frame, width=20)
month_entry.grid(row=1, column=1, sticky="w", padx=5, pady=5)
month_entry.insert(0, datetime.today().strftime("%m/%Y"))
ttk.Button(report_frame, text="View Monthly Summary", command=on_view_month).grid(
    row=1, column=2, padx=5, pady=5
)

output_frame = ttk.LabelFrame(main_frame, text="Report / Messages", padding=10)
output_frame.pack(fill="both", expand=True)

output = tk.Text(output_frame, height=14, wrap="word", font=("Consolas", 10), state="disabled")
output.pack(side="left", fill="both", expand=True)

scrollbar = ttk.Scrollbar(output_frame, orient="vertical", command=output.yview)
scrollbar.pack(side="right", fill="y")
output.configure(yscrollcommand=scrollbar.set)

ttk.Label(
    main_frame,
    text="Your data is saved locally in expenses.csv and allowance.csv.",
    font=("Segoe UI", 9)
).pack(anchor="w", pady=(10, 0))

root.mainloop()

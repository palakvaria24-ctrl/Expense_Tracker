# Personal Expense Tracker

A simple desktop expense tracker built with Python and Tkinter. It lets you add expenses, view daily spending, and view monthly summaries against a monthly allowance.

## Features
- Add expenses with date, category, amount, and note.
- Choose Food, Travel, Shopping, Bills, or a custom category.
- View daily expenses and spending advice.
- View monthly totals, category breakdowns, allowance, and remaining balance.
- Automatically stores data in local CSV files.

## Requirements
- Python 3.10 or newer
- Tkinter (included with most standard Windows Python installations)

No third-party Python packages are required.

## Run on Windows
1. Download or clone this repository.
2. Open the project folder in VS Code.
3. Open Terminal → New Terminal.
4. Run:

   ```powershell
   python expense_tracker.py
   ```

A desktop window should open. If `python` is not recognized, try:

```powershell
py expense_tracker.py
```

## Data files
The application creates `expenses.csv` and `allowance.csv` beside `expense_tracker.py` the first time it runs. These files contain your personal expense records. They are ignored by Git by default so private financial information is not accidentally published.

## Date formats
- Expense date: `DD/MM/YYYY`
- Monthly report: `MM/YYYY`

## Privacy
Expense records are stored locally on your computer. Do not commit personal CSV records or other private information to a public repository.
